﻿Public Class frmTestMove
    Dim intVSpeed As Integer
    Dim intHSpeed As Integer
    Private Sub frmTestMove_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        intVSpeed = 5
        intHSpeed = 5
    End Sub

    Private Sub tmrMoveBoat_Tick(sender As Object, e As EventArgs) Handles tmrMoveBoat.Tick
        'Checks to see if boat hits left or right side of screen
        If imgBoat.Location.X + imgBoat.Width >= Me.ClientSize.Width Or imgBoat.Location.X <= 0 Then
            intHSpeed = intHSpeed * -1
        End If
        'Checks to see if boat hits top or bottom of screen
        If imgBoat.Location.Y + imgBoat.Height >= Me.ClientSize.Height Or imgBoat.Location.Y <= 0 Then
            intVSpeed = intVSpeed * -1
        End If


        imgBoat.Location = New Point(imgBoat.Location.X + intHSpeed, imgBoat.Location.Y + intVSpeed)
    End Sub
End Class
